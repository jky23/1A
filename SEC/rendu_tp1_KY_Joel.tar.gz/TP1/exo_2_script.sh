read -n 1 valeur"Etes-vous satisfaits ? (o/n) "
while [[$valeur != "o"]] || [[$valeur != "n"]]
do
  read -n 1 valeur"Etes-vous satisfaits ? (o/n) "
done
