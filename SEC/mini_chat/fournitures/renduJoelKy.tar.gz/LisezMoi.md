Contenu de ce répertoire
------------------------
Le code fourni consiste en trois squelettes d'applications à compléter, destinés à alléger
votre travail de programmation du minichat.

- serveur.c est le squelette de l'application serveur de la version Serveur du minichat
- console.c est le squelette de l'application client de la version Serveur du minichat
- chatmmap.c est le squelette de l'application pour un participant de la version
	tableau blanc du minichat.
	
Quelques primitives utiles
--------------------------
`fprintf, fgets, fdopen, bzero, memcpy, strcpy, strcmp`