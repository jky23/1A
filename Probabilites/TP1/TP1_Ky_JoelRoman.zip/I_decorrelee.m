function I_decorrelee = I_decorrelee (I)

